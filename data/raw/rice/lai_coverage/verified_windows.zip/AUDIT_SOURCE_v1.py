"""Temporary, bounded multi-year LAI coverage audit. No training labels are read."""
import sys
from pathlib import Path
ROOT = Path.cwd()
WORK = ROOT / '.lai-coverage-work'
sys.path.insert(0, str(WORK / 'runtime'))
import hashlib
import io
import json
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
import requests
import numpy as np
import rasterio
from rasterio.mask import mask
from rasterio.warp import transform_geom, reproject, Resampling
from rasterio.features import bounds, geometry_mask
from rasterio.windows import from_bounds, Window, transform as window_transform

RAW = ROOT / 'data/raw/rice/lai_coverage'
OUT = ROOT / 'data/processed/rice/lai_coverage'
RAW.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
YEARS = [2004, 2013, 2022]
CODES = ['370', '372', '230', '364', '409', '340']
STATES = {'21': 'Odisha', '10': 'Bihar', '20': 'Jharkhand', '22': 'Chhattisgarh', '19': 'West Bengal'}
GEOGRAPHY = ROOT / 'data/processed/rice/seasonal_geography/reference_geometries.geojson'
features = json.loads(GEOGRAPHY.read_text())['features']
districts = [next(f for f in features if f['properties']['district_code_census2011'] == c) for c in CODES]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8', newline='\n')

plan = {'declared_date': '2026-10-22', 'status': 'coverage_only_not_modelling', 'years': YEARS,
        'districts': [{'code': f['properties']['district_code_census2011'],
                       'district': f['properties']['district_census2011'],
                       'state': STATES[f['properties']['state_code_census2011']]} for f in districts],
        'scope': 'Purposive six-district sample fully contained by h25v06; not representative of India or all study districts.',
        'product': 'MCD15A2H Collection 6.1', 'collection': 'modis-15A2H-061', 'tile': 'h25v06',
        'season': 'Composite start >=June 1 and full 8-day interval completed by December 1 exclusive.',
        'mask': 'APRA500 Y-2; rice=1, non-rice=0, nodata=3. Annual paddy extent proxy, not season-specific.',
        'quality': 'raw LAI<=100; bit0=0; SCF bits5-7<=1; dead-detector bit2=0; strict additionally cloud bits3-4=0.',
        'coverage_threshold': .5, 'threshold_role': 'Fixed descriptive coverage screen, not proof of representative yield inputs.',
        'cutoffs': {'August issue': 'composite exclusive end <=August 25', 'October issue': 'composite exclusive end <=October 25'},
        'geography_sha256': sha(GEOGRAPHY.read_bytes()),
        'runtime': {'rasterio': rasterio.__version__, 'numpy': np.__version__},
        'label_access': 'No yield file read; dates/districts/quality fixed without outcome selection.',
        'script_sha256': sha(Path(__file__).read_bytes())}
if (OUT/'plan.json').exists():
    assert json.loads((OUT/'plan.json').read_text()) == plan
else:
    write(OUT/'plan.json', plan)

def get_json(url, params=None):
    last = None
    for attempt in range(3):
        try:
            response = requests.get(url, params=params, timeout=(15,60))
            response.raise_for_status()
            return response.json()
        except requests.RequestException as error:
            last = error
            time.sleep(1+attempt)
    raise last

publisher = get_json('https://zenodo.org/api/records/5557022')
mask_sources = []
for year in YEARS:
    mask_year = year-2
    entry = next(f for f in publisher['files'] if f['key'] == f'paddyRice{mask_year}.tif')
    path = RAW/f'APRA500_paddyRice{mask_year}.tif'
    if not path.exists():
        response = requests.get(entry['links']['self'], timeout=(15,90))
        response.raise_for_status()
        assert len(response.content) < 16*1024*1024
        assert 'md5:'+hashlib.md5(response.content).hexdigest() == entry['checksum']
        path.write_bytes(response.content)
    assert 'md5:'+hashlib.md5(path.read_bytes()).hexdigest() == entry['checksum']
    mask_sources.append({'year': mask_year, 'file': path.name, 'url': entry['links']['self'],
                         'publisher_checksum': entry['checksum'], 'sha256': sha(path.read_bytes())})
    print('Verified mask', mask_year, flush=True)

items = []
missing = []
expected_dates = {}
for year in YEARS:
    payload = get_json('https://planetarycomputer.microsoft.com/api/stac/v1/search', {
        'collections': 'modis-15A2H-061', 'bbox': '83.2,20.8,84.2,21.8',
        'datetime': f'{year}-06-01T00:00:00Z/{year}-12-01T00:00:00Z', 'limit': 1000})
    assert not any(link.get('rel') == 'next' for link in payload.get('links', [])), 'Unexpected unhandled catalogue page'
    selected = {}
    for item in payload['features']:
        if not item['id'].startswith('MCD15A2H.') or '.h25v06.' not in item['id']:
            continue
        start = datetime.fromisoformat(item['properties']['start_datetime'].replace('Z','+00:00'))
        end = start+timedelta(days=8)
        if start < datetime(year,6,1,tzinfo=timezone.utc) or end > datetime(year,12,1,tzinfo=timezone.utc):
            continue
        assert start.isoformat() not in selected, 'Duplicate product for composite'
        selected[start.isoformat()] = item
    expected_dates[year] = []
    for doy in range(1,366,8):
        start = datetime(year,1,1,tzinfo=timezone.utc)+timedelta(days=doy-1)
        end = start+timedelta(days=8)
        if start >= datetime(year,6,1,tzinfo=timezone.utc) and end <= datetime(year,12,1,tzinfo=timezone.utc):
            expected_dates[year].append(start)
            if start.isoformat() not in selected:
                missing.append({'year':year,'composite_start':start.isoformat(),'status':'catalogue_missing'})
    items.extend(sorted(selected.values(),key=lambda item:item['properties']['start_datetime']))
    print('Catalogue year',year,'composites',len(selected),flush=True)
write(RAW/'catalogue_items.json', {'items':items,'mask_sources':mask_sources,'missing_expected_composites':missing})

def evaluate(raw, flags, rice):
    denominator = int(rice.sum())
    main = rice & (raw <=100) & ((flags & 1)==0) & ((flags>>5)<=1) & ((flags & 4)==0)
    strict = main & (((flags>>3)&3)==0)
    return {'rice_pixels': denominator, 'main_valid_pixels':int(main.sum()), 'strict_valid_pixels':int(strict.sum()),
            'main_coverage':float(main.sum()/denominator) if denominator else None,
            'strict_coverage':float(strict.sum()/denominator) if denominator else None,
            'strict_mean_lai_diagnostic':float(raw[strict].mean()*.1) if strict.any() else None,
            'passes_50_percent':bool(denominator and strict.sum()/denominator >= .5)}

def process(item):
    start = datetime.fromisoformat(item['properties']['start_datetime'].replace('Z','+00:00'))
    year, stamp = start.year, start.strftime('%Y%m%d')
    cache = WORK/(stamp+'.npz')
    rows_path = WORK/(stamp+'.json')
    if cache.exists() and rows_path.exists():
        return json.loads(rows_path.read_text()), cache
    signed = {name:get_json('https://planetarycomputer.microsoft.com/api/sas/v1/sign',{'href':item['assets'][name]['href']})['href']
              for name in ('Lai_500m','FparLai_QC')}
    settings = dict(GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR', CPL_VSIL_CURL_ALLOWED_EXTENSIONS='.tif',
                    GDAL_HTTP_CONNECTTIMEOUT='15', GDAL_HTTP_TIMEOUT='60', GDAL_HTTP_MAX_RETRY='2',
                    GDAL_HTTP_RETRY_DELAY='2', GDAL_CACHEMAX=64*1024*1024)
    rows, arrays = [], {}
    with rasterio.Env(**settings), rasterio.open(signed['Lai_500m']) as lai, rasterio.open(signed['FparLai_QC']) as qc, rasterio.open(RAW/f'APRA500_paddyRice{year-2}.tif') as rice_source:
        assert lai.crs == qc.crs and lai.transform == qc.transform and lai.shape == qc.shape
        assert rice_source.crs.to_epsg()==4326 and rice_source.nodata==3
        for feature in districts:
            prop=feature['properties']; code=prop['district_code_census2011']
            geometry=transform_geom('EPSG:4326',lai.crs,feature['geometry'])
            x0,y0,x1,y1=bounds(geometry); box=lai.bounds
            assert box.left<=x0 and box.bottom<=y0 and box.right>=x1 and box.top>=y1, 'Partial sample tile'
            values, target_transform=mask(lai,[geometry],crop=True,filled=False)
            quality, qtransform=mask(qc,[geometry],crop=True,filled=False)
            assert target_transform==qtransform
            # Read only a small source mask window so GDAL cannot materialize the full Asia raster.
            b0,b1,b2,b3=bounds(feature['geometry'])
            source_window=from_bounds(b0-.02,b1-.02,b2+.02,b3+.02,transform=rice_source.transform).round_offsets().round_lengths()
            source=rice_source.read(1,window=source_window)
            mapped=np.full(values.shape[1:],3,dtype=np.uint8)
            reproject(source=source,destination=mapped,src_transform=window_transform(source_window,rice_source.transform),
                      src_crs=rice_source.crs,src_nodata=3,dst_transform=target_transform,dst_crs=lai.crs,
                      dst_nodata=3,resampling=Resampling.nearest)
            # Denominator is geometry + mapped rice, never conditional on LAI being present.
            interior=geometry_mask([geometry],out_shape=values.shape[1:],transform=target_transform,invert=True)
            assert set(np.unique(mapped[interior]).tolist()).issubset({0,1}), 'Unknown rice class or missing mask coverage'
            rice=interior & (mapped==1)
            raw=values[0].filled(255).astype(np.uint8); flags=quality[0].filled(255).astype(np.uint8)
            arrays[code+'_lai']=raw; arrays[code+'_qc']=flags; arrays[code+'_rice']=rice
            rows.append({'year':year,'composite_start':start.date().isoformat(),
                         'composite_end_exclusive':(start+timedelta(days=8)).date().isoformat(),
                         'item_id':item['id'],'district_code_census2011':code,'district':prop['district_census2011'],
                         'state':STATES[prop['state_code_census2011']],'mask_year':year-2,
                         **evaluate(raw,flags,rice)})
    np.savez_compressed(cache,**arrays)
    write(rows_path,rows)
    return rows,cache

records,entries,failures=[],[],[]
with ThreadPoolExecutor(max_workers=3) as pool:
    jobs={pool.submit(process,item):item for item in items}
    for index,future in enumerate(as_completed(jobs),1):
        item=jobs[future]
        try:
            rows,cache=future.result()
            records.extend(rows); entries.append({'name':cache.name,'sha256':sha(cache.read_bytes()),'item_id':item['id']})
            print(f'Checked {index}/{len(items)}: '+rows[0]['composite_start'],flush=True)
        except Exception as error:
            # Record failure and keep it out of the apparent valid-data numerator.
            failures.append({'item_id':item['id'],'error_type':type(error).__name__,
                             'message':str(error).split('?')[0][:300]})
            print(f'Failed {index}/{len(items)}: '+item['id'],type(error).__name__,flush=True)

import pandas as pd
if not records:
    write(OUT/'audit.json',{'status':'coverage_audit_failed','failures':failures,'catalogue_missing':missing})
    raise RuntimeError('No completed composites; inspect audit.json')
data=pd.DataFrame(records).sort_values(['year','composite_start','district_code_census2011'])
data.to_csv(OUT/'coverage.csv',index=False,lineterminator='\n')
archive=RAW/'verified_windows.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_STORED) as bundle:
    for entry in sorted(entries,key=lambda entry:entry['name']):
        bundle.write(WORK/entry['name'],entry['name'])
    bundle.writestr('WINDOW_MANIFEST.json',json.dumps(entries,indent=2))
    bundle.write(Path(__file__),'AUDIT_SOURCE.py')

summary=[]
for (year,code),group in data.groupby(['year','district_code_census2011']):
    for cutoff in [f'{year}-08-25',f'{year}-10-25',f'{year}-12-01']:
        section=group.loc[group.composite_end_exclusive.le(cutoff)]
        expected=sum(1 for start in expected_dates[year] if (start+timedelta(days=8)).date().isoformat()<=cutoff)
        summary.append({'year':int(year),'district_code_census2011':code,'district':group.district.iloc[0],
                        'state':group.state.iloc[0],'cutoff_exclusive':cutoff,'expected_composites':expected,
                        'checked_composites':len(section),'composites_passing_50_percent':int(section.passes_50_percent.sum()),
                        'median_strict_coverage':float(section.strict_coverage.median()) if len(section) else None})
pd.DataFrame(summary).to_csv(OUT/'cutoff_summary.csv',index=False,lineterminator='\n')
report={'status':'coverage_audit_complete' if not failures and not missing else 'coverage_audit_incomplete',
        'plan_sha256':sha((OUT/'plan.json').read_bytes()),'expected_composites':sum(map(len,expected_dates.values())),
        'catalogue_composites':len(items),'successful_composites':len(entries),
        'district_composite_rows':len(data),'failures':failures,'catalogue_missing':missing,
        'source_manifest_sha256':sha((RAW/'catalogue_items.json').read_bytes()),'window_archive_sha256':sha(archive.read_bytes()),
        'outputs_sha256':{name:sha((OUT/name).read_bytes()) for name in ['coverage.csv','cutoff_summary.csv']},
        'scope':plan['scope'],'no_model_or_master_change':True}
write(OUT/'audit.json',report)
print(json.dumps(report,indent=2),flush=True)
